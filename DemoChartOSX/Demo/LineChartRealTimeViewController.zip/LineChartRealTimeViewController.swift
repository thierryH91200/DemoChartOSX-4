//
//  LineChartRealTimeViewController.swift
//  DemoChartOSX
//
//  Created by thierryH24100 on 25/08/2017.
//  Copyright © 2017 thierryH24100. All rights reserved.
//

import Cocoa
import Charts


class LineChartRealTimeViewController: NSViewController {
    
    @IBOutlet var chartView : LineChartView!
    
    @IBOutlet weak var time: NSTextField!
    
    var yEntries = [ChartDataEntry]()
    var currentCount = 0.0
    
    var timer  : Timer?
    var step = 0.0
    
    override func viewWillDisappear()
    {
        super.viewWillDisappear()
        if timer != nil {
            timer!.invalidate()
            timer = nil
        }
    }
    
    override public func viewDidAppear() {
        super.viewDidAppear()
        view.window!.title = "Real Time Line"
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        chartView.isDrawBordersEnabled = true
        chartView.isDrawGridBackgroundEnabled = true
        chartView.gridBackgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        
        chartView.chartDescription?.isEnabled = false
        
        
        let leftAxis = chartView.leftAxis
        leftAxis.axisMaximum = 15
        leftAxis.axisMinimum = 0
        
        let rightAxis = chartView.rightAxis
        rightAxis.isEnabled = false
        
        let marker = RectMarker(color: #colorLiteral(red: 0.9994240403, green: 0.9855536819, blue: 0, alpha: 1), font: Font.systemFont(ofSize: CGFloat(12.0)), insets: NSEdgeInsets(top: 8.0, left: 8.0, bottom: 4.0, right: 4.0))
        marker.chartView = chartView
        marker.minimumSize = CGSize(width: CGFloat(60.0), height: CGFloat(30.0))
        chartView.marker = marker
        
        initData()
    }
    
    func initData()
    {
        let xAxis = chartView.xAxis
        xAxis.labelPosition = .bottom
        xAxis.axisMinimum = 0.0
        xAxis.axisMaximum = 50.0
        
        currentCount = 10
        time.intValue = Int32(currentCount)
        
        yEntries.removeAll()
        
//        yEntries = (0..<Int(currentCount)).map { (i) -> ChartDataEntry in
//            let val = Double(arc4random_uniform(UInt32(10))) + 2
//            return ChartDataEntry(x: Double(i), y: val)
//        }
        
        step = 0.2

        for i in stride(from: 0, to: 10, by: step) {
            let val = Double(arc4random_uniform(UInt32(10))) + 2
            yEntries.append(ChartDataEntry(x: i, y: val))
        }
        
        var set1 = LineChartDataSet()
        set1 = LineChartDataSet(values: yEntries, label: "DataSet 1")
        set1.axisDependency = .left
        set1.setColor(NSColor.blue)
        set1.highlightColor = .black
        set1.highlightLineDashPhase = 1.0
        
        set1.isDrawCirclesEnabled = false
        set1.isDrawFilledEnabled = false
        set1.isDrawValuesEnabled = false
        set1.mode = .cubicBezier
        
        var dataSets = [LineChartDataSet]()
        dataSets.append(set1)
        
        let data = LineChartData(dataSets: dataSets)
        data.setValueTextColor(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 1))
        data.setValueFont(Font(name: "HelveticaNeue-Light", size: CGFloat(9.0))!)
        chartView.data = data
    }
    
    @objc func addValuesToChart()
    {
        let yValue = Double(arc4random_uniform(UInt32(10))) + 2
        let chartEntry = ChartDataEntry(x: currentCount, y: yValue)
        yEntries.append(chartEntry)
        
        print(currentCount,"   ", yEntries.count,"   ", (50 / step))

        
        if yEntries.count == Int(50 / step)
        {
            chartView.xAxis.resetCustomAxisMax()
            chartView.xAxis.resetCustomAxisMin()
        }
        
        if yEntries.count >= Int(50 / step)
        {
            yEntries.removeFirst()
        }
        
        chartView.moveViewToX(Double(currentCount))
        time.intValue = Int32(currentCount)
        currentCount = currentCount + step
        
        var set1 = LineChartDataSet()
        set1 = (chartView.data?.dataSets[0] as? LineChartDataSet)!
        
        set1.values = yEntries
        chartView.data?.notifyDataChanged()
        chartView.notifyDataSetChanged()
    }
    
    @IBAction func pauseButton(_ sender: Any) {
        
        if timer != nil {
            timer!.invalidate()
            timer = nil
        }
    }
    
    @IBAction func playButton(_ sender: Any) {
        if timer != nil {
            timer!.invalidate()
            timer = nil
        }
        timer = Timer.scheduledTimer(timeInterval: step, target: self, selector: #selector(self.addValuesToChart), userInfo: nil, repeats: true)
    }
    
    
    @IBAction func resetData(_ sender: Any) {
        initData()
    }
}
